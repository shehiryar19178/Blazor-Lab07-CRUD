﻿using Microsoft.Data.Sqlite;
using Model;

namespace DAL;

public class ProductRepository : IProductRepository
{
    private readonly string _connectionString;

    public ProductRepository(string connectionString)
    {
        _connectionString = connectionString;
        EnsureTable();
    }

    private void EnsureTable()
    {
        using var con = new SqliteConnection(_connectionString);
        con.Open();
        var cmd = con.CreateCommand();
        cmd.CommandText = @"CREATE TABLE IF NOT EXISTS Product_Info (
                            P_Id INTEGER PRIMARY KEY AUTOINCREMENT,
                            Name TEXT NOT NULL,
                            Price REAL NOT NULL,
                            Category TEXT NOT NULL)";
        cmd.ExecuteNonQuery();
    }

    public List<Product> GetAll()
    {
        var list = new List<Product>();
        using var con = new SqliteConnection(_connectionString);
        con.Open();
        var cmd = con.CreateCommand();
        cmd.CommandText = "SELECT P_Id, Name, Price, Category FROM Product_Info ORDER BY P_Id";
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            list.Add(new Product
            {
                P_Id = reader.GetInt32(0),
                Name = reader.GetString(1),
                Price = (decimal)reader.GetDouble(2),
                Category = reader.GetString(3)
            });
        }
        return list;
    }

    public Product? GetById(int id)
    {
        using var con = new SqliteConnection(_connectionString);
        con.Open();
        var cmd = con.CreateCommand();
        cmd.CommandText = "SELECT P_Id, Name, Price, Category FROM Product_Info WHERE P_Id = $id";
        cmd.Parameters.AddWithValue("$id", id);
        using var reader = cmd.ExecuteReader();
        if (!reader.Read()) return null;
        return new Product
        {
            P_Id = reader.GetInt32(0),
            Name = reader.GetString(1),
            Price = (decimal)reader.GetDouble(2),
            Category = reader.GetString(3)
        };
    }

    public void Add(Product product)
    {
        using var con = new SqliteConnection(_connectionString);
        con.Open();
        var cmd = con.CreateCommand();
        cmd.CommandText = @"INSERT INTO Product_Info (Name, Price, Category) VALUES ($name, $price, $category)";
        cmd.Parameters.AddWithValue("$name", product.Name);
        cmd.Parameters.AddWithValue("$price", product.Price);
        cmd.Parameters.AddWithValue("$category", product.Category);
        cmd.ExecuteNonQuery();
    }

    public void Update(Product product)
    {
        using var con = new SqliteConnection(_connectionString);
        con.Open();
        var cmd = con.CreateCommand();
        cmd.CommandText = @"UPDATE Product_Info SET Name = $name, Price = $price, Category = $category WHERE P_Id = $id";
        cmd.Parameters.AddWithValue("$name", product.Name);
        cmd.Parameters.AddWithValue("$price", product.Price);
        cmd.Parameters.AddWithValue("$category", product.Category);
        cmd.Parameters.AddWithValue("$id", product.P_Id);
        cmd.ExecuteNonQuery();
    }

    public void Delete(int id)
    {
        using var con = new SqliteConnection(_connectionString);
        con.Open();
        var cmd = con.CreateCommand();
        cmd.CommandText = "DELETE FROM Product_Info WHERE P_Id = $id";
        cmd.Parameters.AddWithValue("$id", id);
        cmd.ExecuteNonQuery();
    }
}